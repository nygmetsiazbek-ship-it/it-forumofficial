
  # IT Forum

  This is a code bundle for IT Forum. The original project is available at https://www.figma.com/design/BM5zVyJlu9xSj7b17zOmrL/IT-Forum.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  